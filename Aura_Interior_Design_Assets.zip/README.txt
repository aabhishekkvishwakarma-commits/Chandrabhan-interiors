AURA INTERIOR DESIGN — ASSET FOLDER
=========================================

Source:
00_original_design.jpg

This folder contains assets extracted/cropped from the supplied promotional design.
The extracted images are crops of the original artwork; they are not the original
source files or separate high-resolution photographs.

FILES
-----
01_branding_logo.jpg              Brand/logo area
02_main_hero_interior.jpg         Main living-room hero image
03_feature_highlights.jpg         Right-side selling points
04_contact_info_strip.jpg         Experience, address, phone, service area
05-11_...jpg                      Full service cards
12_bottom_trust_badges.jpg        Bottom assurance/features strip
13-18_..._photo.jpg               Image-focused service crops
19_india_services_map.jpg         India service-area graphic

BRAND DETAILS VISIBLE IN DESIGN
--------------------------------
Brand: AURA INTERIOR DESIGN
Tagline: TRANSFORMING SPACES, ELEVATING LIFESTYLES
Experience: 30+ YEARS OF EXPERIENCE
Location: JB NAGAR, ANDHERI EAST, MUMBAI - 400059
Phone: +91 98202 60856
Services: ALL OVER INDIA

NOTE
----
For a professional editable asset kit, the original logo/vector files, individual
photographs, fonts, icons and editable source (PSD/AI/Figma) would be needed.
